/* import React from "react";
import { useState, useEffect } from "react";
import "./App.css";
import mondaySdk from "monday-sdk-js";
import "@vibe/core/tokens";
//Explore more Monday React Components here: https://vibe.monday.com/
import { AttentionBox } from "@vibe/core";

// Usage of mondaySDK example, for more information visit here: https://developer.monday.com/apps/docs/introduction-to-the-sdk/
const monday = mondaySdk();

const App = () => {
  const [context, setContext] = useState();
  const [user, setUser] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    // Notice this method notifies the monday platform that user gains a first value in an app.
    // Read more about it here: https://developer.monday.com/apps/docs/mondayexecute#value-created-for-user/
    monday.execute("valueCreatedForUser");

    // TODO: set up event listeners, Here`s an example, read more here: https://developer.monday.com/apps/docs/mondaylisten/
    monday.listen("context", (res) => {
      setContext(res.data);
    });
    // Get full user info (name, email)
    monday.api(`query { me { id name email } }`)
      .then((res) => setUser(res.data.me))
      .catch((err) => {
        console.error("Failed to get user info:", err);
        setError("Failed to load user details.");
      });


  }, []);
  if (error) return <AttentionBox title="Error" text={error} />;
  if (!context || !user) return <div>Loading Monday context…</div>;


  //Some example what you can do with context, read more here: https://developer.monday.com/apps/docs/mondayget#requesting-context-and-settings-data
  /* const attentionBoxText = `Hello, your user_id is: ${
    context ? context.user.id : "still loading"
  }.
  Let's start building your amazing app, which will change the world!`;
*/
/*
  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
    <h2>👋 Hello, {user.name}</h2>
    <p>You’re viewing board ID: <strong>{context.boardId}</strong></p>
    <hr />
    <p>Next step: Add your token and send a query.</p>
  </div>
  );
};

export default App;
*/
import React, { useEffect, useState } from "react";
import "./App.css";
import mondaySdk from "monday-sdk-js";
import "@vibe/core/tokens";
import { AttentionBox } from "@vibe/core";
import { AttentionBox, Input, Button } from "@vibe/core";


const monday = mondaySdk();

const App = () => {
  const [context, setContext] = useState(null);
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("avoda_token") || "");
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    monday.execute("valueCreatedForUser");

    // SAFELY fetch context once
    monday.get("context").then((res) => {
      console.log("✅ Context (get):", res.data);
      setContext(res.data);
    });

    // Optionally also listen for live context updates (filter changes, etc)
    monday.listen("context", (res) => {
      console.log("📦 Context (listen):", res.data);
      setContext(res.data);
    });

    // Get full user info
    monday
      .api(`query { me { id name email } }`)
      .then((res) => {
        console.log("👤 User info:", res.data.me);
        setUser(res.data.me);
      })
      .catch((err) => {
        console.error("❌ Failed to get user:", err);
        setError("Failed to load user details.");
      });
  }, []);

  const handleTokenSave = () => {
    if (token.trim() === "") {
      setSaved(false);
      setError("Token cannot be empty.");
      return;
    }

    localStorage.setItem("avoda_token", token.trim());
    setSaved(true);
    setError("");
    console.log("🔐 Token saved");
  };

  if (error) return <AttentionBox title="Error" text={error} />;
  if (!context || !user) return <div>Loading Monday context…</div>;

  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h2>👋 Hello, {user.name}</h2>
      <p>You're viewing board ID: <strong>{context.boardId}</strong></p>
      <hr />
      <p>Next step: Add your token and send a query.</p>

      <h3>🔑 API Token</h3>
      <Input
        value={token}
        placeholder="Paste your Bearer token here"
        onChange={(e) => setToken(e.target.value)}
      />
      <Button style={{ marginTop: "0.5rem" }} onClick={handleTokenSave}>Save Token</Button>
      {saved && <p style={{ color: "green" }}>✅ Token saved!</p>}
      <hr />

      <p>Next step: build a GraphQL query runner.</p>

    </div>
  );
};

export default App;
