// src/mondayClient.ts
import mondaySdk from "monday-sdk-js";
const monday = mondaySdk();

export default monday;
